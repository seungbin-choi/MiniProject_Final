import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import Register_sje from './components_sje/Register_sje';
import Login_sje from './components_sje/Login_sje';
import 'bootstrap/dist/css/bootstrap.css';

function App() {
  return (
    <div>
      <Router>
        <Route path='/login_sje' component={Login_sje} exact={true} />
        <Route path='/register_sje' component={Register_sje} />
      </Router>
    </div>
  );
}

export default App;