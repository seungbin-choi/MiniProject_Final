import React from 'react';
import { Link } from 'react-router-dom';
import Container from 'react-bootstrap/Container'
import '../css_sje/login_sje.css';

function Login_sje() {
    return (
        <div id='login_sje'>
            <div className='header'>
            <Container>
                <Link to='/sje'>
                    <img className='logo' src="images_sje/logo_sje.svg" alt="logo" />
                </Link>
            </Container>
            </div>
            <Container>
            <div className='login_content'>
                <h3>로그인</h3>
                <div className='login_input'>
                    <span className='input_name'>아이디</span>
                    <input type="text" name="아이디" placeholder='아이디' />
                </div>
                <div className='login_input'>
                    <span className='input_name'>비밀번호</span>
                    <input type="password" name="비밀번호" placeholder='비밀번호' />
                </div>
                <div className='login_input2'>
                    <input className='login_b' type="submit" value='로그인' />
                    <Link className='login_link' to="/register_sje">회원가입</Link>
                </div>
            </div>
            </Container>
        </div>
    );
}

export default Login_sje;