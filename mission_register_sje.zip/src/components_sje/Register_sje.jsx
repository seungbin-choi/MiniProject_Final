import React, { useCallback, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import Container from 'react-bootstrap/Container';
import '../css_sje/register_sje.css';

function Register_sje() {
    const [domain, setDomain] = useState('');
    const [isCustomDomain, setIsCustomDomain] = useState(false);
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [passwordError, setPasswordError] = useState('');

    // useRef를 사용하여 각 입력 필드에 접근할 수 있는 참조 변수를 생성합니다.
    const postcodeRef = useRef(null);
    const addressRef = useRef(null);
    const detailAddressRef = useRef(null);
    const extraAddressRef = useRef(null);  

    const handleDomainChange = (event) => {
        const selectedDomain = event.target.value;
        if (selectedDomain === "custom") {
            setIsCustomDomain(true);
            setDomain('');
        } else {
            setIsCustomDomain(false);
            setDomain(selectedDomain);
        }
    };

    const getTodayDate = () => {
        const today = new Date();
        const year = today.getFullYear();
        const month = String(today.getMonth() + 1).padStart(2, '0');
        const day = String(today.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    };

    const handlePasswordChange = (event) => {
        setPassword(event.target.value);
    };

    const handleConfirmPasswordChange = (event) => {
        setConfirmPassword(event.target.value);
        if (password !== event.target.value) {
            setPasswordError('*비밀번호가 일치하지 않습니다');
        } else {
            setPasswordError('');
        }
    };

    // 주소 검색 버튼이 클릭될 때 실행될 함수입니다.
    // useCallback을 사용하여 함수 재생성을 방지하고, 성능을 최적화합니다.
    const handleAddressSearch = useCallback(() => {
    // Daum 주소 검색 API를 호출합니다.
    new window.daum.Postcode({
      oncomplete: function (data) {
        let addr = ''; // 주소 저장 변수
        let extraAddr = ''; // 참고 항목 저장 변수

        // 사용자가 선택한 주소 타입에 따라 주소 정보를 설정합니다.
        if (data.userSelectedType === 'R') { // 도로명 주소인 경우
          addr = data.roadAddress;
        } else { // 지번 주소인 경우
          addr = data.jibunAddress;
        }

        // 도로명 주소 선택 시, 참고항목을 추가합니다.
        if (data.userSelectedType === 'R') {
          if (data.bname !== '' && /[동|로|가]$/g.test(data.bname)) {
            extraAddr += data.bname;
          }
          if (data.buildingName !== '' && data.apartment === 'Y') {
            extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
          }
          extraAddr = extraAddr ? ` (${extraAddr})` : '';
        }

        // 입력 필드에 검색 결과를 설정합니다.
        postcodeRef.current.value = data.zonecode; // 우편번호 입력
        addressRef.current.value = addr; // 주소 입력
        extraAddressRef.current.value = extraAddr; // 참고항목 입력
        detailAddressRef.current.focus(); // 상세주소 필드로 포커스 이동
      }
    }).open();
  }, []);



    return (
        <div id='register_sje'>
            <div className='header'>
                <Container>
                    <Link to='/sje'>
                        <img className='logo' src="images_sje/logo_sje.svg" alt="logo" />
                    </Link>
                </Container>
            </div>
            <Container>
                <div className='register_content'>
                    <h3>회원가입</h3>
                    <div className='register_input'>
                        <span className='input_name'>아이디</span>
                        <input type="text" name="아이디" placeholder="아이디" />
                    </div>
                    <div className='register_input'>
                        <span className='input_name'>비밀번호</span>
                        <input
                            type="password"
                            name="비밀번호"
                            placeholder="비밀번호"
                            value={password}
                            onChange={handlePasswordChange}
                        />
                    </div>
                    <div className='register_input'>
                        <span className='input_name'>비밀번호 확인</span>
                        <input
                            type="password"
                            name="비밀번호 확인"
                            placeholder="비밀번호 확인"
                            value={confirmPassword}
                            onChange={handleConfirmPasswordChange}
                        />
                        <p
                            className='passwordError'
                            style={{ visibility: passwordError ? 'visible' : 'hidden' }}
                        >
                            {passwordError}
                        </p>
                    </div>
                    <br />
                    <div className='register_input'>
                        <span className='input_name'>이름</span>
                        <input type="text" name="이름" placeholder="이름" />
                    </div>
                    <div className='register_input'>
                        <span className='input_name'>생년월일</span>
                        <input
                            type="date"
                            name="생년월일"
                            max={getTodayDate()}
                            placeholder="생년월일"
                        />
                    </div>
                    <div>
                    <span className='input_name'>이메일</span>
                        <div className='register_input email-container'>
                            <input type="text" name="이메일" placeholder="이메일" />
                            <span className='at'>@</span>
                            {isCustomDomain ? (
                                <input 
                                    type="text" 
                                    value={domain} 
                                    onChange={(e) => setDomain(e.target.value)} 
                                    placeholder="도메인 입력"
                                />
                            ) : (
                                <select value={domain} onChange={handleDomainChange}>
                                    <option value="">도메인 선택</option>
                                    <option value="naver.com">naver.com</option>
                                    <option value="gmail.com">gmail.com</option>
                                    <option value="hanmail.net">hanmail.net</option>
                                    <option value="nate.com">nate.com</option>
                                    <option value="kakao.com">kakao.com</option>
                                    <option value="custom">직접 입력</option>
                                </select>
                            )}
                        </div>
                        </div>
                    {/* <div className='register_input'>
                        <span className='input_name'>주소</span>
                        <input className='add' type="text" ref={postcodeRef} placeholder="우편번호" readOnly />
                        <button className='add-b' onClick={handleAddressSearch}>우편번호 찾기</button><br />
                        <input type="text" ref={addressRef} placeholder="주소" size={45} readOnly /><br />
                        <input type="text" ref={detailAddressRef} size={45} placeholder="상세주소" />
                        <input type="text" ref={extraAddressRef} size={45} placeholder="참고항목" className="hidden" />      
                    </div> */}
                    <div className='register_input2'>
                        <input className='register_b' type="submit" value="회원가입" />
                        <Link to="/login_sje" className='register-link'>로그인 페이지</Link>
                    </div>
                </div>
            </Container>
        </div>
    );
}

export default Register_sje;
