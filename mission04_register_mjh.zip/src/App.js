import React from 'react';
import{BrowserRouter as Router, Route} from 'react-router-dom'
import Register_mjh from './components/Register_mjh';

function App() {
  return (
    <div>
      <Router>
        <Route path="/mjh" component={Register_mjh}/>  

      </Router>
    </div>
      );
}

export default App;