import React, { useState,useCallback } from 'react';
import '../css/register.css';
import {useHistory} from 'react-router-dom';

function Register_mjh() {
  const history = useHistory()
    const goToMain = () => {
      history.push("/")
    }
    // 주소 검색 버튼 클릭 시 실행될 함수
  const handleAddressSearch = useCallback(() => {
    // Daum 주소 검색 API를 호출
    new window.daum.Postcode({
      oncomplete: function (data) {
        let addr = ''; // 주소 저장 변수
        let extraAddr = ''; // 참고 항목 저장 변수

        // 사용자가 선택한 주소 타입에 따라 주소 정보를 설정
        if (data.userSelectedType === 'R') { // 도로명 주소인 경우
          addr = data.roadAddress;
        } else { // 지번 주소인 경우
          addr = data.jibunAddress;
        }

        // 도로명 주소 선택 시, 참고항목을 추가
        if (data.userSelectedType === 'R') {
          if (data.bname !== '' && /[동|로|가]$/g.test(data.bname)) {
            extraAddr += data.bname;
          }
          if (data.buildingName !== '' && data.apartment === 'Y') {
            extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
          }
          extraAddr = extraAddr ? ` (${extraAddr})` : '';
        }

        // 주소와 참고 항목을 합친 전체 주소
        const fullAddress = `${addr} ${extraAddr}`;

        // 부모 창으로 전체 주소를 전달하고 팝업 창을 닫음
        window.opener.postMessage({ fullAddress }, '*');
        window.close();
      }
    }).open();
  }, []);

    return (
        <div >
            <div className='register_title'>
                <h1>회원가입</h1>
                <div className='regiWrapper'>
                    <form >
                        <label> 아이디 </label>
                         <input type="text" id='id' placeholder='아이디 입력' size={35} />
                        <label> 이름 </label>
                         <input type="text" id='name' placeholder='이름 입력' size={35}/>
                        <label> 비밀번호</label>
                         <input type="password" id='pw' placeholder='비밀번호 입력' size={35}/> <br />
                        <label> 비밀번호 확인 </label>
                         <input type="password" id='confirmPassword' placeholder='비밀번호 확인 입력' size={35}/>
                        <label> 주소 </label>                      
                          <input type="text" placeholder="우편번호" size={20}readOnly />
                          <button className='mjh_btn' onClick={handleAddressSearch}>우편번호 찾기</button><br /><br />
                          <input type="text" placeholder="주소" size={35} readOnly /><br /><br />
                          <input type="text" size={35} placeholder="상세주소" /><br />
                    </form>
                    <br />
                    <button className='mjh_btn' formAction=''>회원가입</button>
                    <button className='mjh_btn' onClick={goToMain}>메인으로</button>
                </div>
            </div>
        </div>
    );
}

export default Register_mjh;