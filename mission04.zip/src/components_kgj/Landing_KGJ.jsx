import React from "react";
import { Link } from "react-router-dom";

const Landing_KGJ = () => {
  return (
    <div>
      <h1>김국진의 페이지</h1>
      <Link to="/">메인으로</Link> |<Link to="/company-kgj">회사 소개</Link>
    </div>
  );
};

export default Landing_KGJ;
