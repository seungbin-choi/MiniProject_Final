import React from "react";
import { Link } from "react-router-dom";

const CompanyInfo_JNR = () => {
  return (
    <div>
      <h1>장나라의 회사 소개</h1>
      <Link to="/">메인으로</Link> |<Link to="/faq-jnr">자주 묻는 질문</Link>
    </div>
  );
};

export default CompanyInfo_JNR;
