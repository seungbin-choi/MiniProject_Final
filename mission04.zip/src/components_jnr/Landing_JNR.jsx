import React from "react";
import { Link } from "react-router-dom";

const Landing_JNR = () => {
  return (
    <div>
      <h1>장나라의 페이지</h1>
      <Link to="/">메인으로</Link> |<Link to="/company-jnr">회사 소개</Link>
    </div>
  );
};

export default Landing_JNR;
