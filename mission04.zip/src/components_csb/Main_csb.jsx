import React, { useState } from 'react';
import '../css/Main_csb.css'; // CSS 파일을 import합니다.
import Navbar_csb from './Navbar_csb'; // Navbar_csb 컴포넌트를 import합니다.
import Footer_csb from './Footer_csb';

const services = Array.from({ length: 7 }, (_, index) => `서비스 ${index + 1}`); // 7개의 서비스 항목을 생성합니다.

function Main_csb() {
    const [currentIndex, setCurrentIndex] = useState(0); // 현재 보여주는 서비스 박스의 인덱스를 관리합니다.

    const handlePrev = () => {
        if (currentIndex > 0) {
            setCurrentIndex(currentIndex - 4); // 이전 버튼 클릭 시 인덱스를 감소시킵니다.
        }
    };

    const handleNext = () => {
        if (currentIndex < services.length - 4) { // 4개의 박스가 화면에 보이는 경우
            setCurrentIndex(currentIndex + 4); // 다음 버튼 클릭 시 인덱스를 증가시킵니다.
        }
    };

    return (
        <div className="container_main">
            <Navbar_csb /> {/* Navbar_csb 컴포넌트를 추가합니다 */}
            <div className='Main_csb'>대한민국 정부24</div>
            <div className="video-wrapper_main">
                <iframe 
                    src="https://www.youtube.com/embed/lqLqrFU2wb8" 
                    title="YouTube video player" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowFullScreen>
                </iframe>
            </div>
            <div className="services-wrapper_main">
                <div className="services-container_main" style={{ transform: `translateX(-${currentIndex * 25}%)` }}>
                    {services.map((service, index) => (
                        <div key={index} className="service-box_main">
                            {service}
                        </div>
                    ))}
                </div>
                <div className="nav-buttons_main">
                    <button onClick={handlePrev}>&lt; </button> {/* 이전 버튼 */}
                    <button onClick={handleNext}> &gt;</button> {/* 다음 버튼 */}
                </div>
            </div>
            <Footer_csb/>
            {/* <Footer_csb /> Footer_csb 컴포넌트를 추가합니다 */}
        </div>
    );
}

export default Main_csb;
