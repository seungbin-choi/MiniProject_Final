import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'; // Bootstrap CSS를 import 합니다.
import '../css/Qna_csb.css'; // 사용자 정의 CSS를 import 합니다.
import Navbar_csb from './Navbar_csb'; // Navbar_csb 컴포넌트를 import합니다.
import Footer_csb from './Footer_csb';

function Qna_csb() {
    return (
        <div className="page-container">
            <Navbar_csb /> 
            <div className="content-wrap_csb">
                <h1 className="h1_csb text-center mb-4">자주 묻는 질문 (Q&A)</h1>
                <div className="accordion" id="accordionExample">
                    <div className="accordion-item">
                        <h2 className="accordion-header" id="headingOne">
                            <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                질문 1: 정부24는 무엇인가요?
                            </button>
                        </h2>
                        <div id="collapseOne" className="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                            <div className="accordion-body">
                                <strong>정부24</strong>는 대한민국 정부가 제공하는 다양한 공공서비스와 정보를 한 곳에서 조회하고 신청할 수 있는 온라인 포털 서비스입니다.
                            </div>
                        </div>
                    </div>
                    <div className="accordion-item">
                        <h2 className="accordion-header" id="headingTwo">
                            <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                질문 2: 정부24에서 제공하는 서비스는 무엇인가요?
                            </button>
                        </h2>
                        <div id="collapseTwo" className="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                            <div className="accordion-body">
                                <strong>정부24</strong>에서는 주민등록등본, 건강보험 자격득실 확인서, 세금 납부, 복지 서비스 신청 등 다양한 서비스를 제공하고 있습니다.
                            </div>
                        </div>
                    </div>
                    <div className="accordion-item">
                        <h2 className="accordion-header" id="headingThree">
                            <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                질문 3: 정부24를 이용하려면 회원가입이 필요한가요?
                            </button>
                        </h2>
                        <div id="collapseThree" className="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                            <div className="accordion-body">
                                정부24의 일부 서비스는 비회원으로도 이용할 수 있으나, 다양한 혜택을 누리기 위해서는 회원가입을 권장합니다.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer_csb className="footer_csb"/>
        </div>
    );
}

export default Qna_csb;
