import React from "react";
import { Link } from "react-router-dom";

const Landing_KHS = () => {
  return (
    <div>
      <h1>김희선의 페이지</h1>
      <Link to="/">메인으로</Link> |<Link to="/company-khs">회사 소개</Link>
    </div>
  );
};

export default Landing_KHS;
