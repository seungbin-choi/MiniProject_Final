import React from "react";
import { BrowserRouter as Router, Route, Link, Switch } from "react-router-dom";
import Home from "./common/Home";
import Landing_KGJ from "./components_kgj/Landing_KGJ";
import Landing_KHS from "./components_khs/Landing_KHS";
import Landing_JNR from "./components_jnr/Landing_JNR";
import Landing_LYA from "./components_lya/Landing_LYA";
import CompanyInfo_KGJ from "./components_kgj/CompanyInfo_KGJ";
import CompanyInfo_KHS from "./components_khs/CompanyInfo_KHS";
import CompanyInfo_JNR from "./components_jnr/CompanyInfo_JNR";
import CompanyInfo_LYA from "./components_lya/CompanyInfo_LYA";
import FAQ_csb from "./components_csb/FAQ_csb";
import FAQ_KGJ from "./components_kgj/FAQ_KGJ";
import FAQ_KHS from "./components_khs/FAQ_KHS";
import FAQ_JNR from "./components_jnr/FAQ_JNR";
import FAQ_LYA from "./components_lya/FAQ_LYA";
import LandingPage_csb from "./components_csb/Landing_Csb";
import About_csb from "./components_csb/About_csb";
import Main_csb from "./components_csb/Main_csb";
import Location_csb from "./components_csb/Location_csb";
import LoginPage_csb from "./components_csb/LoginPage_csb";

function App() {
  return (
    <Router>
      <div>
        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/csb" component={LandingPage_csb} />
          <Route path="/kgj" component={Landing_KGJ} />
          <Route path="/khs" component={Landing_KHS} />
          <Route path="/jnr" component={Landing_JNR} />
          <Route path="/lya" component={Landing_LYA} />
          <Route path="/main_csb" component={Main_csb} />
          <Route path="/about_csb" component={About_csb} />
          <Route path="/company-kgj" component={CompanyInfo_KGJ} />
          <Route path="/company-khs" component={CompanyInfo_KHS} />
          <Route path="/company-jnr" component={CompanyInfo_JNR} />
          <Route path="/company-lya" component={CompanyInfo_LYA} />
          <Route path="/qna_csb" component={FAQ_csb} />
          <Route path="/faq-kgj" component={FAQ_KGJ} />
          <Route path="/faq-khs" component={FAQ_KHS} />
          <Route path="/faq-jnr" component={FAQ_JNR} />
          <Route path="/faq-lya" component={FAQ_LYA} />
          <Route path="/location_csb" component={Location_csb} />
          <Route path="/csb_login" component={LoginPage_csb} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
