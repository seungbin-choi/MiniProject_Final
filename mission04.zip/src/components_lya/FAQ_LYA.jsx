import React from "react";
import { Link } from "react-router-dom";

const FAQ_LYA = () => {
  return (
    <div>
      <h1>이영애의 자주 묻는 질문</h1>
      <Link to="/lya">랜딩페이지로 바로가기</Link>
    </div>
  );
};

export default FAQ_LYA;
