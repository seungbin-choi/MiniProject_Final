import React from 'react';
import { Route, Switch } from 'react-router-dom';
import './App.css';
import Navbar_csb from './components/Navbar_csb';
import About_csb from './components/About_csb';
import Footer_csb from './components/Footer_csb'; // Footer 컴포넌트 import
import LandingPage_csb from './components/LandingPage_csb'; // LandingPage_csb 컴포넌트 import
import Location_csb from './components/Location_csb';
import Main_csb from './components/Main_csb';
import Qna_csb from './components/Qna_csb';
import LoginPage_csb from './components/LoginPage_csb';

function App() {
  return (
    <div className="App">
      <Navbar_csb />
      <div className="container mt-4">
        <Switch>
          <Route path="/" component={LandingPage_csb} exact={true}/>
          <Route path="/main_csb" component={Main_csb}/>
          <Route path="/about_csb" component={About_csb} />
          <Route path="/location_csb" component={Location_csb} />
          <Route path="/qna_csb" component={Qna_csb} />
          <Route path="/csb_login" component={LoginPage_csb} />
        </Switch>
      </div>
      <Footer_csb/>
    </div>
  );
}

export default App;
