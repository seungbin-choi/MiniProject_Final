import React from 'react';

function Home() {
  return (
    <div className="container">
      <h2>홈 페이지</h2>
      <p>공공기관 홈페이지에 오신 것을 환영합니다.</p>
    </div>
  );
}

export default Home;
