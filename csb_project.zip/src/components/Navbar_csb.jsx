import React, { useState } from 'react'; // React와 useState 훅을 import합니다.
import { Link } from 'react-router-dom'; // react-router-dom의 Link 컴포넌트를 import합니다.
import { Navbar, NavbarBrand, Nav, NavItem, Dropdown, DropdownToggle, DropdownMenu, DropdownItem, NavbarToggler, Collapse } from 'reactstrap'; // Reactstrap의 다양한 컴포넌트를 import합니다.
import '../css/Navbar_csb.css'; // CSS 스타일을 import합니다.

function Navbar_csb() { // Navbar_csb 함수형 컴포넌트를 정의합니다.
  const [isOpen, setIsOpen] = useState(false); // 네비게이션 바의 열림 상태를 관리하는 상태 훅입니다.
  const [dropdownOpen, setDropdownOpen] = useState({ // 각 드롭다운의 열림 상태를 관리하는 상태 훅입니다.
    home: false, //false 인 이유는 닫혀있어야 되서
    about: false,
    services: false,
    contact: false,
    navigation: false,
    qna: false // Q&A 드롭다운의 초기 상태를 false로 설정합니다.
  });

  const toggle = () => setIsOpen(!isOpen); // 네비게이션 바의 열림 상태를 토글하는 함수입니다.

  const toggleDropdown = (dropdown) => { // 드롭다운의 열림 상태를 토글하는 함수입니다.
    setDropdownOpen(prevState => ({
      ...prevState,
      [dropdown]: !prevState[dropdown] // 특정 드롭다운의 상태를 반전시킵니다.
    }));
  };

  return (
    <Navbar color="light" light expand="md"> {/* 네비게이션 바를 생성합니다. */}
      <NavbarBrand tag={Link} to="/main_csb" className="navbar-brand"> {/* 네비게이션 바의 브랜드 부분을 정의하며, 링크로 감싸집니다. */}
        <img src="/images/go.png" alt="Logo" className="logo" /> {/* 로고 이미지를 삽입합니다. */}
        정부24 {/* 브랜드 텍스트입니다. */}
      </NavbarBrand>
      <NavbarToggler onClick={toggle} /> {/* 네비게이션 바를 열거나 닫기 위한 토글 버튼입니다. */}
      <Collapse isOpen={isOpen} navbar> {/* 네비게이션 바의 collapsible 부분을 정의합니다. */}
        <Nav className="ml-auto" navbar> {/* 네비게이션 항목을 담는 Nav 컴포넌트입니다. */}
          <NavItem> {/* 네비게이션 항목을 정의합니다. */}
            <Dropdown isOpen={dropdownOpen.home} toggle={() => toggleDropdown('home')}> {/* '홈' 드롭다운 메뉴를 정의합니다. */}
              <DropdownToggle nav caret> {/* 드롭다운의 토글 버튼입니다. */}
                홈 {/* 드롭다운 메뉴의 제목입니다. */}
              </DropdownToggle>
              <DropdownMenu> {/* 드롭다운 메뉴 항목들을 포함합니다. */}
                <DropdownItem tag={Link} to="/">서브 메뉴 1</DropdownItem> {/* 서브 메뉴 항목 1 */}
                <DropdownItem tag={Link} to="/">서브 메뉴 2</DropdownItem> {/* 서브 메뉴 항목 2 */}
              </DropdownMenu>
            </Dropdown>
          </NavItem>
          <NavItem>
            <Dropdown isOpen={dropdownOpen.about} toggle={() => toggleDropdown('about')}> {/* 'About' 드롭다운 메뉴를 정의합니다. */}
              <DropdownToggle nav caret> {/* 드롭다운의 토글 버튼입니다. */}
                About {/* 드롭다운 메뉴의 제목입니다. */}
              </DropdownToggle>
              <DropdownMenu> {/* 드롭다운 메뉴 항목들을 포함합니다. */}
                <DropdownItem tag={Link} to="/about_csb/mission">미션</DropdownItem> {/* 미션 페이지로 이동하는 항목 */}
                <DropdownItem tag={Link} to="/about_csb/team">팀</DropdownItem> {/* 팀 페이지로 이동하는 항목 */}
              </DropdownMenu>
            </Dropdown>
          </NavItem>
          <NavItem>
            <Dropdown isOpen={dropdownOpen.services} toggle={() => toggleDropdown('services')}> {/* '서비스' 드롭다운 메뉴를 정의합니다. */}
              <DropdownToggle nav caret> {/* 드롭다운의 토글 버튼입니다. */}
                서비스 {/* 드롭다운 메뉴의 제목입니다. */}
              </DropdownToggle>
              <DropdownMenu> {/* 드롭다운 메뉴 항목들을 포함합니다. */}
                <DropdownItem tag={Link} to="/services/service1">서비스 1</DropdownItem> {/* 서비스 1 페이지로 이동하는 항목 */}
                <DropdownItem tag={Link} to="/services/service2">서비스 2</DropdownItem> {/* 서비스 2 페이지로 이동하는 항목 */}
              </DropdownMenu>
            </Dropdown>
          </NavItem>
          <NavItem>
            <Dropdown isOpen={dropdownOpen.contact} toggle={() => toggleDropdown('contact')}> {/* '연락처' 드롭다운 메뉴를 정의합니다. */}
              <DropdownToggle nav caret> {/* 드롭다운의 토글 버튼입니다. */}
                연락처 {/* 드롭다운 메뉴의 제목입니다. */}
              </DropdownToggle>
              <DropdownMenu> {/* 드롭다운 메뉴 항목들을 포함합니다. */}
                <DropdownItem tag={Link} to="/contact/email">이메일</DropdownItem> {/* 이메일 페이지로 이동하는 항목 */}
                <DropdownItem tag={Link} to="/contact/phone">전화</DropdownItem> {/* 전화 페이지로 이동하는 항목 */}
              </DropdownMenu>
            </Dropdown>
          </NavItem>
          <NavItem>
            <Dropdown isOpen={dropdownOpen.navigation} toggle={() => toggleDropdown('navigation')}> {/* '찾아오시는 길' 드롭다운 메뉴를 정의합니다. */}
              <DropdownToggle nav caret> {/* 드롭다운의 토글 버튼입니다. */}
                찾아오시는길 {/* 드롭다운 메뉴의 제목입니다. */}
              </DropdownToggle>
              <DropdownMenu> {/* 드롭다운 메뉴 항목들을 포함합니다. */}
                <DropdownItem tag={Link} to="/location_csb">위치</DropdownItem> {/* 위치로 이동하는 항목 */}
              </DropdownMenu>
            </Dropdown>
          </NavItem>
          <NavItem> {/* Q&A 네비게이션 항목을 정의합니다. */}
            <Dropdown isOpen={dropdownOpen.qna} toggle={() => toggleDropdown('qna')}> {/* Q&A 드롭다운 메뉴를 정의합니다. */}
              <DropdownToggle nav caret> {/* 드롭다운의 토글 버튼입니다. */}
                Q&A {/* 드롭다운 메뉴의 제목입니다. */}
              </DropdownToggle>
              <DropdownMenu> {/* 드롭다운 메뉴 항목들을 포함합니다. */}
                <DropdownItem tag={Link} to="/qna_csb">Q&A 페이지</DropdownItem> {/* Q&A 페이지로 이동하는 항목 */}
              </DropdownMenu>
            </Dropdown>
          </NavItem>
          <ul className='right_csb' justify-content-end>
          <Link to='/csb_login' className='csb_login'> Login</Link>
          </ul>
        </Nav>
      </Collapse>
    </Navbar>
  );
}

export default Navbar_csb; // 컴포넌트를 export합니다.

