import React from 'react';
import { Link } from 'react-router-dom';
import '../css/LoginPage_csb.css';

const LoginPage_csb = () => {
  return (
      <div className="login-box">
        <h2>정부 24</h2>
        <form>
          <div className="form-group">
            <label htmlFor="username">아이디</label>
            <input type="text" id="username" name="username" placeholder="아이디를 입력하세요" />
          </div>
          <div className="form-group">
            <label htmlFor="password">비밀번호</label>
            <input type="password" id="password" name="password" placeholder="비밀번호를 입력하세요" />
          </div>
          <button type="submit" className="btn-login">로그인</button>
        </form>
        <div className="links">
          <Link to="/signup">회원가입하러 가기</Link>
        </div>
        <div className="additional-links">
          <Link to="/find-id">아이디 찾기</Link>
          <span className="separator">|</span>
          <Link to="/find-password">비밀번호 찾기</Link>
        </div>
      </div>
  );
};

export default LoginPage_csb;
